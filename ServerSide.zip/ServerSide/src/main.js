const express = require("express");
const cors = require("cors");

const dbaddDoctor = require("./DB.Operations");

const app = express();
app.use(cors());
app.use(express.json());

app.post("/adddoctor", async (req, res) => {
  console.log("Main Method Started...............");
    try {
      const input = req.body;
      //console.log(input);
      await dbaddDoctor.addDoctor(input);
      res.json({ message: "Successfully data inserted" });
    } catch (err) {
      res.json({ message: "failed !!!" });
    }
  });
  app.post("/auth-user", async (req, res) => {
    try {
      const input = req.body;
      //console.log(input);
      await dbaddDoctor.authUser(input);
      res.json({ opr: true });
    } catch (err) {
      res.json({ opr: false });
    }
  });
  app.get("/showusers", async (req, res) => {
    try {
      // lets read the query parameter
      //const input = req.query;
      //console.log("inside show users");
      // calling db logic :: async :: non blocking
      let results = await dbaddDoctor.showUsers();
      //console.log(results);
  
      res.json(results);
    } catch (err) {
      res.json({ message: "failure" });
    }
  });
  app.post("/del", async (req, res) => {
    try {
      // lets read the query parameter
      const input = req.body;
      //console.log("inside del users");
      //console.log(input);
      // calling db logic :: async :: non blocking
      await dbaddDoctor.delUsers(input);
  
      res.json({ opr: "true" });
    } catch (err) {
      res.json({ opr: "false" });
    }
  });
  app.post("/emailver", async (req, res) => {
    try {
      console.log("inside email ver post call");
      const input = req.body;
      console.log(input);
      const result = await dbaddDoctor.emailVer(input);
      console.log(result);
      res.json({ msg: true });
    } catch (err) {
      res.json({ msg: false });
    }
  });
  app.listen(3500);