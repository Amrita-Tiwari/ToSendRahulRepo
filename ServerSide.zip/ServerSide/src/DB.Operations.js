const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const DB_CONFIG = {
    host: "localhost",
    user: "root",
    password: "Root@123",
    database: "hms",
  };
  
let addDoctor = async (input) => {
    try {
      console.log(input);
      
      const connection = mysql.createConnection(DB_CONFIG);
      //console.log(input);
      
      await connection.connectAsync();
      console.log(input);
      
      let sql = "INSERT INTO DOCTOR(d_id ,password,name,deptno)  VALUES(?,?,?,?)";
      console.log(input);
  
      //console.log(input.deptno);
     // input.deptno = Number(input.deptno);
      //console.log(input.deptno);
     // console.log(input);
  
      await connection.queryAsync(sql, [
        input.d_id,
        input.password,
        input.name,
        input.deptno,
      ]);
      await connection.endAsync();
    } catch (err) {
      console.log(err);
    }
  };
  let authUser = async (input) => {
    //console.log('inside auth fun');
    const connection = mysql.createConnection(DB_CONFIG);
    await connection.connectAsync();
    //console.log(input);
    let sql = "SELECT * FROM doctor WHERE d_id = ? && password = ?";
  
    console.log(input);
  
    const results = await connection.queryAsync(sql, [
      input.d_id,
      input.password,
    ]);
    //console.log(results);
  
    await connection.endAsync();
  
    if (results.length === 0) {
      throw new Error("Invalid Credentials");
    }
  };
  let showUsers = async (iput) => {
    //console.log("inside get call");
    const connection = mysql.createConnection(DB_CONFIG);
  
    await connection.connectAsync();
  
    let sql = "SELECT * FROM doctor";
    //let sql = "SELECT * FROM lunch WHERE rice = ?";
  
    let results = await connection.queryAsync(sql);
    //console.log(results);
    await connection.endAsync();
    return results;
  };
  
  let delUsers = async (ip) => {
    //console.log("inside get call");
    //console.log(ip);
    const connection = mysql.createConnection(DB_CONFIG);
  
    await connection.connectAsync();
  
    let sql = "DELETE FROM doctor WHERE d_id = ?";
    //let sql = "SELECT * FROM lunch WHERE rice = ?";
  
    await connection.queryAsync(sql, [ip.input]);
    console.log("done");
    await connection.endAsync();
  };
let emailVer = async (input) => {
    const connection = mysql.createConnection(DB_CONFIG);
  
    await connection.connectAsync();
    //console.log("inside email ver");
    //console.log(typeof input.em, input.em);
    //let temp = input.y;
    //console.log(temp);
    //console.log(typeof temp);
  
    let sql = "SELECT * FROM doctor WHERE d_id = ?";
  
    let results = await connection.queryAsync(sql, [input.email]);
    console.log(results);
    await connection.endAsync();
    if (results.length === 0) {
      throw new Error("Invalid Credentials");
    }
  };
  module.exports = {
    addDoctor,
    authUser,
    showUsers,
    delUsers,
    emailVer
  };
  